//
//  NetAccessBase.h
//  MISP
//
//  Created by li yang on 12-7-19.
//  Copyright (c) 2012年 wondersoft. All rights reserved.
//

#import "WSBaseObject.h"


@interface NetAccessBase : WSBaseObject{

    
}




@end
