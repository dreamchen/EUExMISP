//
//  MISP.h
//  MISP
//
//  Created by Mr.Cooriyou on 12-7-19.
//  Copyright (c) 2012年 wondersoft. All rights reserved.
//

#import <Foundation/Foundation.h>




@interface MISP : NSObject
{
    
}

- (void) sayHello;

- (void) testIkey;

- (void)testStrategy;

- (void)testSysStrategy;

- (void)testLevelKey;

@end
